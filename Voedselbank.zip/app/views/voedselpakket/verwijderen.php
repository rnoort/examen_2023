<h1>Voedselpakket verwijderen</h1>
<p>Weet u zeker dat u deze voedselpakket wilt verwijderen?</p>
<a href="<?=URLROOT?>/voedselpakket/definitief/<?= $data['Id'] ?>"><button>Verwijderen</button></a>
<a href="<?=URLROOT?>/voedselpakket/inzien/<?= $data['Id'] ?>"><button>Annuleren</button></a>
