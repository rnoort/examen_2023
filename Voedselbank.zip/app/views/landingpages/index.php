<h1>Homepage voedselbank maaskantje</h1>
<a href="<?= URLROOT ?>/klant/">Overzicht klanten</a>