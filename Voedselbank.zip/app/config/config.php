<?php 
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    // naam van je database
    define('DB_NAME', 'examendrie'); 

    //het padd naar de app map
    define('APPROOT', dirname(dirname(__FILE__)));

    // de url van de website
    define('URLROOT', 'http://www.eindexamen.nl');

    // naam van de website
    define('SITENAME', '...');
    
?>